﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClsComm;
using Common.Controls.Common;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.Utils.Extensions;
using DevExpress.Utils.Helpers;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;

namespace Common
{
    public partial class ViewDev2 : ViewDev
    {
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, UC_XtraGrid> _Grid { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid의 MainView를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, GridView> _View { get; private set; }
        /// <summary>
        /// [GridControl] and [TableLayoutPanel] pair,<br/> 
        /// GridControl에 대응되는 편집판넬이 없다면 Null 입니다.
        /// </summary>
        protected Dictionary<object, UC_TableLayoutPanel> _EditPanel { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 BindingSource를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, BindingSource> _Src { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 BindingSource의 DataTable을 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, DataTable> _Table { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 모든 DataRow의 리스트를 바로 얻을 수 있습니다.
        /// </summary>
        protected Rows _Rows { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid에 포커스 되어진 DataRow를 바로 얻을 수 있습니다.
        /// </summary>
        protected FocusedRow _FocusedRow { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid의 ColumnEdit들을 Column의 FiledName으로 접근할 수 있는 Dictionary가 제공됩니다.
        /// </summary>
        protected ColumnEdits _ColumnEdits { get; private set; }
        /// <summary>
        /// GridControl의 모든 Tag를 int 타입으로 담고 있습니다.
        /// </summary>
        protected List<int> _Tag { get; private set; }
        /// <summary>
        /// ActiveGrid의 Tag를 int 타입으로 얻습니다.
        /// </summary>
        protected int _ActiveGrid { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시고,<br/> 
        /// 또, GridView의 이벤트 이름을 알려주시면 등록된 EventHandle을(를) 모두 얻어드리겠습니다. =ㅅ=乃<br/> 
        /// 하나도 등록되지 않았으면 값은 null입니다. (주의! ViewDevE2_Load() 이전에 등록된 이벤트만)
        /// </summary>
        protected Dictionary<object, Dictionary<EventName, IEnumerable<Delegate>>> _EnrolledEventList { get; private set; }

        /// <summary>
        /// _Table[tag]의 Reference가 변경되었습니다.
        /// </summary>
        protected event TableChangedEventHandler TableChanged;
        protected delegate void TableChangedEventHandler(object sender, TableChangedEventArgs e);
        protected class TableChangedEventArgs : EventArgs
        {
            public int Tag { get; private set; }
            public TableChangedEventArgs(int tag) { Tag = tag; }
        }
        /// <summary>
        /// _Table[tag]의 Reference가 변경되기 전입니다.
        /// </summary>
        protected event TableChangingEventHandler TableChanging;
        protected delegate void TableChangingEventHandler(object sender, TableChangingEventArgs e);
        protected class TableChangingEventArgs : EventArgs
        {
            public int Tag { get; private set; }
            public TableChangingEventArgs(int tag) { Tag = tag; }
        }

        /// <summary>
        /// 키보드의 Arrow Up Down Key로 행이동 중 발생하는 이벤트를 잠시 멈추고 싶으면 True, 아니면 False 입니다. (ViewDev2_Load 이벤트 이후 언제든 사용가능합니다)
        /// </summary>
        protected bool _IsPauseFocusedRowChanged
        {
            get { return _isPauseFocusedRowChanged; }
            set { _actPauseFocusedRowChanged(value); }
        }
        private bool _isPauseFocusedRowChanged;
        private readonly Action<bool> _actPauseFocusedRowChanged;
        private readonly Dictionary<object, dynamic> _pauseFocusedRowChangedEventList = new Dictionary<object, dynamic>();

        /// <summary>
        /// 그리드의 수정을 즉각 반영시키고 싶으면 True, 아니면 False 입니다. (ViewDev2_Load 이벤트 이후 언제든 사용가능합니다)
        /// </summary>
        protected bool _IsEarlier
        {
            get { return _isEarlier; }
            set { _actEarlier(value); }
        }
        private bool _isEarlier;
        private readonly Action<bool> _actEarlier;
        private readonly Dictionary<object, Dictionary<object, EventHandler>> _earlierEventList = new Dictionary<object, Dictionary<object, EventHandler>>();

        /// <summary>
        /// 그리드의 ButtonEdit으로 편집을 마칠 때, ButtonEdit을 Close하고 싶으면 True, 아니면 False 입니다. (ViewDev2_Load 이벤트 이후 언제든 사용가능합니다)
        /// </summary>
        protected bool _IsBtnEditClose
        {
            get { return _isBtnEditClose; }
            set { _actBtnEditClose(value); }
        }
        private bool _isBtnEditClose;
        private readonly Action<bool> _actBtnEditClose;
        private readonly Dictionary<object, Dictionary<object, dynamic>> _btnEditCloseEventList = new Dictionary<object, Dictionary<object, dynamic>>();

        public ViewDev2()
        {
            _actPauseFocusedRowChanged = @bool =>
            {
                if (_isPauseFocusedRowChanged && @bool) return;
                _isPauseFocusedRowChanged = @bool;

                _Tag.ForEach(tag =>
                {
                    if (!_View[tag].HasEnrolledEvent(EventName.FocusedRowChanged)) return;

                    if (!_pauseFocusedRowChangedEventList.ContainsKey(tag))
                        _pauseFocusedRowChangedEventList.Add(tag, new
                        {
                            RemoveEvent = (Action)(() =>
                            {
                                if (!_View[tag].HasEnrolledEvent(EventName.FocusedRowChanged)) return;
                                _EnrolledEventList[tag][EventName.FocusedRowChanged].OfType<FocusedRowChangedEventHandler>().ForEach(@event => _View[tag].FocusedRowChanged -= @event);
                            }),
                            AddEvent = (Action)(() =>
                            {
                                if (_View[tag].HasEnrolledEvent(EventName.FocusedRowChanged)) return;
                                _EnrolledEventList[tag][EventName.FocusedRowChanged].OfType<FocusedRowChangedEventHandler>().ForEach(@event => _View[tag].FocusedRowChanged += @event);
                                _View[tag].TriggerEvent(EventName.FocusedRowChanged);
                            }),
                            KeyEvent = (KeyEventHandler)((o, args) =>
                            {
                                if (NativeMethods.IsDownKeyPressed() || NativeMethods.IsUpKeyPressed())
                                    _pauseFocusedRowChangedEventList[tag].RemoveEvent();
                                else
                                    _pauseFocusedRowChangedEventList[tag].AddEvent();
                            }),
                            LostFocus = (EventHandler)((o, args) => _pauseFocusedRowChangedEventList[tag].AddEvent())
                        });

                    if (@bool)
                    {
                        _View[tag].KeyDown += _pauseFocusedRowChangedEventList[tag].KeyEvent;
                        _View[tag].KeyUp += _pauseFocusedRowChangedEventList[tag].KeyEvent;
                        _View[tag].LostFocus += _pauseFocusedRowChangedEventList[tag].LostFocus;
                    }
                    else
                    {
                        _View[tag].KeyDown -= _pauseFocusedRowChangedEventList[tag].KeyEvent;
                        _View[tag].KeyUp -= _pauseFocusedRowChangedEventList[tag].KeyEvent;
                        _View[tag].LostFocus -= _pauseFocusedRowChangedEventList[tag].LostFocus;
                    }
                });
            };

            _actEarlier = @bool =>
            {
                if (_isEarlier && @bool) return;
                _isEarlier = @bool;

                _Tag.ForEach(tag => _ColumnEdits[tag].ForEach(pair =>
                {
                    if (!_earlierEventList.ContainsKey(tag))
                        _earlierEventList.Add(tag, new Dictionary<object, EventHandler>());
                    if (!_earlierEventList[tag].ContainsKey(pair.Key))
                        _earlierEventList[tag].Add(pair.Key, (o, args) =>
                        {
                            if (_FocusedRow[tag] == null) return;
                            if (_FocusedRow[tag].RowState == DataRowState.Detached) return;
                            var edit = o as BaseEdit;
                            if (edit == null) return;

                            try
                            {
                                if (!_FocusedRow[tag][pair.Key].IsSame(edit.EditValue))
                                    _FocusedRow[tag][pair.Key] = edit.EditValue.IsBlank(DBNull.Value);
                            }
                            catch { /* Ignore */ }
                        });

                    if (@bool)
                        pair.Value.EditValueChanged += _earlierEventList[tag][pair.Key];
                    else
                        pair.Value.EditValueChanged -= _earlierEventList[tag][pair.Key];
                }));
            };

            _actBtnEditClose = @bool =>
            {
                if (_isBtnEditClose && @bool) return;
                _isBtnEditClose = @bool;

                _Tag.ForEach(tag => ((IList<MenuColumnInfo>)_View[tag].Tag)
                    .Where(info => info.COL_TYPE == "2")
                    .Select(info => _ColumnEdits[tag][info.COL_ID])
                    .OfType<RepositoryItemButtonEdit>().ForEach(edit =>
                    {
                        if (!_btnEditCloseEventList.ContainsKey(tag))
                            _btnEditCloseEventList.Add(tag, new Dictionary<object, dynamic>());
                        if (!_btnEditCloseEventList[tag].ContainsKey(edit))
                            _btnEditCloseEventList[tag].Add(edit, new
                            {
                                Click = (ButtonPressedEventHandler)((o, args) => _View[tag].CloseEditor()),
                                Showing = (CancelEventHandler)((o, args) =>
                                {
                                    _View[tag].ShowingEditor -= _btnEditCloseEventList[tag][edit].Showing;
                                    edit.ButtonClick += _btnEditCloseEventList[tag][edit].Click;
                                })
                            });

                        if (@bool)
                            _View[tag].ShowingEditor += _btnEditCloseEventList[tag][edit].Showing;
                        else
                        {
                            _View[tag].ShowingEditor -= _btnEditCloseEventList[tag][edit].Showing;
                            edit.ButtonClick -= _btnEditCloseEventList[tag][edit].Click;
                        }
                    }));
            };

            Load += ViewDev2_Load;
        }

        private void ViewDev2_Load(object sender, EventArgs e)
        {
            if (DesignMode) return;

            if (ActiveGrid == null) return;
            _ActiveGrid = ActiveGrid.Tag.ToInt32(-1);

            _Grid = new Dictionary<object, UC_XtraGrid>();
            _View = new Dictionary<object, GridView>();
            _EditPanel = new Dictionary<object, UC_TableLayoutPanel>();
            _Src = new Dictionary<object, BindingSource>();
            _Table = new Dictionary<object, DataTable>();
            _Rows = new Rows { _Table = _Table };
            _FocusedRow = new FocusedRow { _View = _View };
            _ColumnEdits = new ColumnEdits { _View = _View };
            _Tag = new List<int>();
            _EnrolledEventList = new Dictionary<object, Dictionary<EventName, IEnumerable<Delegate>>>();

            foreach (var grid in GridControls)
            {
                var tag = Convert.ToInt32(grid.Tag);
                _Tag.Add(tag);

                // Column의 FiledName 및 Type이 같아서 Tag를 중복 지정하실 수 있지만,
                // 그리드의 Tag를 각각 다르게 지정해주세요.
                // 아니면, 예외를 return으로 대체 후, _Grid, _View, _EditPanel, _Table, _Rows, _FocusedRow를 사용하지 마세요.
                if (_Grid.ContainsKey(tag))
                    throw new Exception("GridControl의 Tag가 중복되어 있습니다.");
                _Grid.Add(tag, (UC_XtraGrid)grid);
                _Grid[tag].Enter += (o, args) => _ActiveGrid = tag;
                _View.Add(tag, (GridView)grid.MainView);
                _View[tag].ExGetExceptColumns().Add("GU");

                _EditPanel.Add(tag, ComFunction.GetControls(this).OfType<UC_TableLayoutPanel>().FirstOrDefault(tlp => tlp.Tag != null && tlp.Tag.Equals(grid.Tag)));
                if (_EditPanel[tag] != null)
                    ComFunction.SetRequired(_Grid[tag], _EditPanel[tag], "uC_");

                _Table.Add(tag, null);
                _Src.Add(tag, new BindingSource());
                _Src[tag].CurrentChanged += OnCurrentChanged;
                _Src[tag].DataSourceChanged += (o, args) => OnCurrentChanged(_Src[tag], args);
                _Src[tag].BindingComplete += OnBindingComplete;

                // 구분열(GU)의 검사가 사용자 값 입력 마무리 후, 즉각 검사되도록 수정되었습니다.
                _View[tag].ExSetIsAutoGuFlag(false);
                _View[tag].HiddenEditor += (o, args) => _Src[tag].EndEdit();
                _ColumnEdits[tag].Values.OfType<RepositoryItemPopupBase>().ForEach(edit => edit.Closed += (o, args) => _View[tag].CloseEditor());

                // 등록되어진 이벤트들을 리스트로 추가합니다.
                var temp = new[]
                {
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.FocusedRowChanged)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.KeyDown)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.KeyUp)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.ClipboardRowPasting)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.CustomDrawFooterCell)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.CellValueChanged)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.RowStyle)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.ShowingEditor)],
                    _View[tag].Events()[_View[tag].GetEventKeyByName(EventName.RowCellStyle)]
                };
                var list = new Dictionary<EventName, IEnumerable<Delegate>>
                {
                    { EventName.FocusedRowChanged, temp[0] == null ? null : temp[0].GetInvocationList() },
                    { EventName.KeyDown, temp[1] == null ? null : temp[1].GetInvocationList() },
                    { EventName.KeyUp, temp[2] == null ? null : temp[2].GetInvocationList() },
                    { EventName.ClipboardRowPasting, temp[3] == null ? null : temp[3].GetInvocationList() },
                    { EventName.CustomDrawFooterCell, temp[4] == null ? null : temp[4].GetInvocationList() },
                    { EventName.CellValueChanged, temp[5] == null ? null : temp[5].GetInvocationList() },
                    { EventName.RowStyle, temp[6] == null ? null : temp[6].GetInvocationList() },
                    { EventName.ShowingEditor, temp[7] == null ? null : temp[7].GetInvocationList() },
                    { EventName.RowCellStyle, temp[8] == null ? null : temp[8].GetInvocationList() }
                };
                _EnrolledEventList.Add(tag, list);
            }

            _EditPanel.Values.Where(panel => panel != null).ForEach(panel =>
            {
                var tag = Convert.ToInt32(panel.Tag);

                var edits = ComFunction.GetControls(panel).Where(edit =>
                    edit.GetType() == typeof(SearchLookUpEdit) ||
                    edit.GetType() == typeof(TextEdit) ||
                    edit.GetType() == typeof(UC_DevDateTimeEditor) ||
                    edit.GetType() == typeof(CheckEdit) ||
                    edit.GetType() == typeof(ButtonEdit) ||
                    edit.GetType() == typeof(MemoEdit) ||
                    edit.GetType() == typeof(SimpleButton)
                );
                edits.ForEach(edit =>
                {
                    edit.KeyPress += clsFunction.TypingNextStep;
                    edit.MouseWheel += (o, args) => edit.Focus();
                    edit.Enter += GetEnterEventForActiveGrid(tag);
                    var te = edit as TextEdit;
                    if (te == null) return;
                    te.EditValueChanged += (o, args) =>
                    {
                        if (_FocusedRow[tag] == null) return;
                        if (_FocusedRow[tag].RowState == DataRowState.Detached) return;

                        if (!te.Name.IsMatch(@"uC_\w+")) return;
                        var colNm = Regex.Split(te.Name, @"uC_")[1];
                        if (!_Table[tag].Columns.Contains(colNm)) return;

                        try
                        {
                            if (!_FocusedRow[tag][colNm].IsSame(te.EditValue))
                                _FocusedRow[tag][colNm] = te.EditValue.IsBlank(DBNull.Value);
                        }
                        catch { /* Ignore */ }
                    };
                    if (te.Properties.Mask.MaskType != MaskType.DateTime &&
                        te.Properties.Mask.MaskType != MaskType.DateTimeAdvancingCaret) return;
                    te.Properties.AllowMouseWheel = false;
                });
            });

            // 테이블 필드 이름이, 테이블과 연관된 EditPanel 안에 있는 SearchLookUpEdit 컨트롤의 Tag에 달린 이름과 같다면,
            // SearchLookUpEdit 컨트롤의 DisplayMember 값으로 해당 테이블 필드가 바뀌게 적용됩니다.
            Shown += (o, args) =>
            {
                _Tag.ForEach(tag =>
                {
                    if (_EditPanel[tag] == null) return;

                    foreach (GridColumn col in _View[tag].Columns)
                    {
                        var fieldName = col.FieldName;

                        var combo = ComFunction.GetControls(_EditPanel[tag])
                            .OfType<SearchLookUpEdit>()
                            .FirstOrDefault(ctrl => ctrl.Tag.IsSame("uC_" + fieldName, false, true));
                        if (combo == null) continue;

                        var valueMember = combo.Properties.ValueMember;
                        var displayMember = combo.Properties.DisplayMember;
                        var table = combo.Properties.DataSource.ToDataTable();
                        if (table == null) continue;

                        _View[tag].ExGetExceptColumns().Add(fieldName);
                        combo.EditValueChanged += (o0, args0) =>
                        {
                            if (_FocusedRow[tag] == null) return;

                            var row = table.Rows
                                .OfType<DataRow>()
                                .FirstOrDefault(r => r[valueMember].Equals(combo.EditValue));
                            try
                            {
                                if (row == null) return;
                                if (_FocusedRow[tag][fieldName].Equals(row[displayMember])) return;
                                _FocusedRow[tag][fieldName] = row[displayMember];
                            }
                            catch { /* Ignore */ }
                        };
                    }
                });
            };

            Shown += (o, args) =>
            {
                _Tag.ForEach(tag =>
                {
                    // grid.DataSource는 ClsFunction.SetGridColumn()에서 오류가 없었다면 생성되야합니다.
                    // null인 경우, 메뉴컬럼등록을 다시 확인해 주세요. 충분히 해결하실 수 있을겁니다 =ㅅ=乃
                    //
                    // 또는 !! Load 이벤트 시점에서 조회하시면, 사용할 수 없습니다. 지금 등록된 Shown 보다 뒤에서 조회해주세요.
                    if (_Grid[tag].DataSource == null)
                        throw new Exception("메뉴컬럼등록을 다시 확인해 주세요.");
                    _Src[tag].DataSource = _Grid[tag].DataSource;
                    _Grid[tag].DataSource = _Src[tag];
                });
            };

            Shown += (o, args) =>
            {
                var edit = ComFunction.GetControls(this).FirstOrDefault(ctrl => ctrl.Name.Equals("s_Search")) as TextEdit;
                if (edit == null) return;

                edit.GotFocus += (o1, args1) => edit.SelectAll();
                edit.Click += (o1, args1) => edit.SelectAll();
                edit.KeyDown += (o1, args1) =>
                {
                    if (args1.KeyData != Keys.Enter) return;
                    _Search();
                };
            };

            _IsPauseFocusedRowChanged = true;
            _IsEarlier = true;
            _IsBtnEditClose = true;

            _View.Values.ForEach(view =>
            {
                if (view is UC_GridView)
                    ((UC_GridView)view).EnableAppearanceEvenRow = true;
                else if (view is UC_BandedGridView)
                    ((UC_BandedGridView)view).EnableAppearanceEvenRow = true;
                else if (view is UC_AdvBandedGridView)
                    ((UC_AdvBandedGridView)view).EnableAppearanceEvenRow = true;
            });
        }

        private void OnCurrentChanged(object sender, EventArgs e)
        {
            var src = (BindingSource)sender;
            var tag = (int)_Src.First(pair => pair.Value == src).Key;

            var table = _Src[tag].DataSource.ToDataTable();
            if (_Table[tag] == table) return;

            // _Src[tag].DataSource = dt; << 지금 이 순간을 포착했습니다
            if (_View[tag].IsFocusedRowChangeLocked()) _View[tag].UnlockFocusedRowChange();

            if (_Table[tag] != null && TableChanging != null)
                TableChanging(this, new TableChangingEventArgs(tag));

            if (_Table[tag] != null)
                _Table[tag].Dispose();
            _Table[tag] = table;

            if (_Table[tag].Columns.Contains("GU"))
                _Table[tag].Columns["GU"].DefaultValue = "C";
            _Table[tag].Columns
                .OfType<DataColumn>()
                .Where(col => col.DataType == typeof(bool) && col.DefaultValue == DBNull.Value)
                .ForEach(col => col.DefaultValue = false);
            _Table[tag].ColumnChanged += (o, args) =>
            {
                if (!_Table[tag].Columns.Contains("GU")) return;
                if (args.Row["GU"].IsMatch("[CUD]")) return;
                if (_View[tag].ExGetExceptColumns().Contains(args.Column.ColumnName)) return;

                args.Row["GU"] = "U";
            };

            if (TableChanged != null)
                TableChanged(this, new TableChangedEventArgs(tag));

            // DataSource 등록 후 행변경 강제 발생을 위한 밑 작업입니다.
            // tag번째 그리드는 이 순간 Invalid Row를 포커스 후(rowHandle = -2147483648), 이벤트 FocusedRowChanged()가 호출되어집니다.
            // 이 후, 다음 루틴으로 이벤트 FocusedRowChanged()가 불리는 것을 잠시 막습니다.
            SetDataBinding(tag, true);
            _Grid[tag].DataSource = null;

            // 바인딩소스의 객체를 사용하기 위한 준비과정 입니다.
            src.CurrentChanged -= OnCurrentChanged;
            _Src[tag].ResetBindings(true);
            src.CurrentChanged += OnCurrentChanged;

            _View[tag].ClearFilter();

            // 마무리 =ㅅ=乃
            _Grid[tag].DataSource = _Src[tag]; // 이벤트 FocusedRowChanged()가 다시 불립니다.
            SetDataBinding(tag);
        }

        private void SetDataBinding(int tag, bool isClearOnly = false)
        {
            if (_EditPanel[tag] == null) return;

            foreach (DataColumn col in _Table[tag].Columns)
            {
                var foundCtrl = ComFunction.GetControls(_EditPanel[tag]) // 접두어 + 컬럼명으로 컨트롤 찾기
                    .FirstOrDefault(ctrl => ctrl.Name.IsSame("uC_" + col.ColumnName, false, true));
                if (foundCtrl == null) continue; // 찾은 컨트롤이 없으면 다음 컬럼으로 넘김

                foundCtrl.DataBindings.Clear(); // 컨트롤 바인딩 Clear
                if (isClearOnly) continue;

                // 컨트롤 종류에 따라 Value 속성 다르게 처리
                if (foundCtrl is BaseEdit)
                    foundCtrl.DataBindings.Add("EditValue", _Src[tag], col.ColumnName, true, DataSourceUpdateMode.OnValidation);
                else if (foundCtrl.GetType().GetProperty("Value") != null)
                    foundCtrl.DataBindings.Add("Value", _Src[tag], col.ColumnName, true, DataSourceUpdateMode.OnValidation);
            }
        }

        /// <summary>
        /// For using BindingSource. This method will be make to apply immediately. ( Eg. ("TEST")Txt_Test.Text -> ultraGrid1.ActiveRow.Cells["TEST"].Value )
        /// 바인딩소스를 사용하기위함. 해당 기능은 적용이 즉시 되도록함.( Eg. ("TEST")Txt_Test.Text -> ultraGrid1.ActiveRow.Cells["TEST"].Value )
        /// </summary>
        private static void OnBindingComplete(object sender, BindingCompleteEventArgs e)
        {
            // Check if the data source has been updated, and that no error has occurred.
            if (e.BindingCompleteContext == BindingCompleteContext.DataSourceUpdate && e.Exception == null)
                e.Binding.BindingManagerBase.EndCurrentEdit(); // If not, end the current edit.

            e.Binding.ControlUpdateMode = ControlUpdateMode.OnPropertyChanged;
            ((BindingSource)sender).EndEdit();
        }

        protected EventHandler GetEnterEventForActiveGrid(int tag)
        {
            return (o, args) =>
            {
                if (_ActiveGrid == tag) return;

                _View[_ActiveGrid].ExSetIsActiveGrid(false);
                _View[_ActiveGrid].Invalidate();
                ActiveGrid = _Grid[tag];
                _ActiveGrid = tag;
                _View[tag].ExSetIsActiveGrid(true);
                _View[tag].Invalidate();
            };
        }

        private readonly Dictionary<int, Dictionary<string, Action<DataRow>>> _checkCode = new Dictionary<int, Dictionary<string, Action<DataRow>>>();
        private readonly Dictionary<int, Dictionary<string, dynamic>> _checkCodeEvent = new Dictionary<int, Dictionary<string, dynamic>>();
        private readonly Dictionary<int, Dictionary<string, bool>> _checkCodeEventFlag = new Dictionary<int, Dictionary<string, bool>>();
        private readonly Dictionary<int, Dictionary<string, Dictionary<object, dynamic>>> _valueList = new Dictionary<int, Dictionary<string, Dictionary<object, dynamic>>>();
        /// <summary>
        /// 사용자가 그리드에서 코드값을 편집하게 되면, 매개변수로 얻은 내용을 바탕으로 올바른 코드인지 판단하고, 값을 올바르게 고칩니다.
        /// </summary>
        /// <param name="tag">코드 검사가 필요한 그리드의 tag</param>
        /// <param name="code">코드의 필드명(ex. ItemCode)</param>
        /// <param name="names">코드에 따라 값이 바뀌는 종속된 이름들의 필드명(ex. ItemName, ItemSpec ...)</param>
        /// <param name="sql">코드가 올바른지 판단하는 질의문</param>
        protected void SetCheckCodeEventForGridView(int tag, string code, string[] names, string sql)
        {
            if (!_checkCode.ContainsKey(tag))
            {
                _checkCode.Add(tag, new Dictionary<string, Action<DataRow>>());
                _checkCodeEvent.Add(tag, new Dictionary<string, dynamic>());
                _checkCodeEventFlag.Add(tag, new Dictionary<string, bool>());
                _valueList.Add(tag, new Dictionary<string, Dictionary<object, dynamic>>());
            }

            if (_checkCode[tag].ContainsKey(code))
                throw new Exception("이미 알려주신 코드의 필드명에 대한 검사 루틴이 존재합니다");

            _checkCode[tag].Add(code, row =>
            {
                if (_valueList[tag][code].ContainsKey(row[code]))
                {
                    if (!row[code].Equals(_valueList[tag][code][row[code]].Code))
                        row[code] = _valueList[tag][code][row[code]].Code;
                    Enumerable.Range(0, names.Length).ForEach(i =>
                    {
                        if (row[names[i]].Equals(_valueList[tag][code][row[code]].Name[i])) return;
                        row[names[i]] = _valueList[tag][code][row[code]].Name[i];
                    });
                    return;
                }
                try
                {
                    var dt = clsDbcon.DrtRecordDataSet(string.Format(sql, row[code])).Tables[0];
                    if (dt.Rows.Count == 1)
                    {
                        _valueList[tag][code].Add(row[code], new
                        {
                            Code = dt.Rows[0][code],
                            Name = new object[names.Length]
                        });
                        Enumerable.Range(0, names.Length).ForEach(i => _valueList[tag][code][row[code]].Name[i] = dt.Rows[0][names[i]]);
                        Enumerable.Range(0, names.Length).ForEach(i =>
                        {
                            if (row[names[i]].Equals(_valueList[tag][code][row[code]].Name[i])) return;
                            row[names[i]] = _valueList[tag][code][row[code]].Name[i];
                        });

                        if (row[code].Equals(_valueList[tag][code][row[code]].Code)) return;
                        if (!_valueList[tag][code].ContainsKey(_valueList[tag][code][row[code]].Code))
                            _valueList[tag][code].Add(_valueList[tag][code][row[code]].Code, new
                            {
                                _valueList[tag][code][row[code]].Code,
                                _valueList[tag][code][row[code]].Name
                            });
                        row[code] = _valueList[tag][code][row[code]].Code;
                    }
                    else
                    {
                        row[code] = DBNull.Value;
                        names.ForEach(name => row[name] = DBNull.Value);
                    }
                }
                catch { /* Ignore */ }
            });
            _checkCodeEvent[tag].Add(code, new
            {
                HiddenEditor = (EventHandler)((o, args) =>
                {
                    if (!_View[tag].FocusedColumn.FieldName.Equals(code)) return;
                    if (_FocusedRow[tag] == null) return;
                    _checkCode[tag][code](_FocusedRow[tag]);
                }),
                ColumnChanged = (DataColumnChangeEventHandler)((o, args) =>
                {
                    if (!args.Column.ColumnName.Equals(code) && !names.Any(name => name.Equals(args.Column.ColumnName))) return;
                    if (_View[tag].IsEditing) return;
                    _checkCode[tag][code](args.Row);
                }),
                TableChanged = (TableChangedEventHandler)((o, args) =>
                {
                    if (_Table[tag] == null) return;
                    _Table[tag].ColumnChanged += _checkCodeEvent[tag][code].ColumnChanged;
                })
            });
            _checkCodeEventFlag[tag].Add(code, false);
            _valueList[tag].Add(code, new Dictionary<object, dynamic>
            {
                { DBNull.Value, new
                {
                    Code = DBNull.Value,
                    Name = Enumerable.Range(0, names.Length).Select(i => (object)DBNull.Value).ToArray()
                }}
            });
            
            _View[tag].HiddenEditor += _checkCodeEvent[tag][code].HiddenEditor;
            TableChanged += _checkCodeEvent[tag][code].TableChanged;
        }

        protected void SetCheckCodeEventForGridView(int tag, string code, bool isPause)
        {
            if (!_checkCode.ContainsKey(tag))
                throw new Exception("알려주신 검사 루틴이 없습니다");
            if (!_checkCode[tag].ContainsKey(code))
                throw new Exception("알려주신 검사 루틴이 없습니다");
            if (_checkCodeEventFlag[tag][code] == isPause) return;

            if (isPause)
            {
                _View[tag].HiddenEditor -= _checkCodeEvent[tag][code].HiddenEditor;
                _Table[tag].ColumnChanged -= _checkCodeEvent[tag][code].ColumnChanged;
                TableChanged -= _checkCodeEvent[tag][code].TableChanged;
            }
            else
            {
                _View[tag].HiddenEditor += _checkCodeEvent[tag][code].HiddenEditor;
                _Table[tag].ColumnChanged += _checkCodeEvent[tag][code].ColumnChanged;
                TableChanged += _checkCodeEvent[tag][code].TableChanged;
            }

            _checkCodeEventFlag[tag][code] = isPause;
        }
    }

    public class FocusedRow
    {
        public Dictionary<object, GridView> _View { get; set; }

        public DataRow this[object tag]
        {
            get { return _View[tag].IsDataRow(_View[tag].FocusedRowHandle) ? _View[tag].GetFocusedDataRow() : null; }
        }
    }

    public class Rows
    {
        public Dictionary<object, DataTable> _Table { get; set; }

        public List<DataRow> this[object tag]
        {
            get { return _Table[tag].DefaultView.OfType<DataRowView>().Select(row => row.Row).ToList(); }
        }
    }

    public class ColumnEdits
    {
        public Dictionary<object, GridView> _View { get; set; }
        private Dictionary<object, Dictionary<string, RepositoryItem>> _Result { get; set; }

        public ColumnEdits()
        {
            _Result = new Dictionary<object, Dictionary<string, RepositoryItem>>();
        }

        public Dictionary<string, RepositoryItem> this[object tag]
        {
            get
            {
                if (_Result.ContainsKey(tag)) return _Result[tag];

                _Result.Add(tag, new Dictionary<string, RepositoryItem>());
                _View[tag].Columns.ForEach(col => _Result[tag].Add(col.FieldName, col.ColumnEdit));
                return _Result[tag];
            }
        }
    }

    #region Class

    public class MsgException : Exception
    {
        public string As_MsgType { get; private set; }
        public string As_Type { get; private set; }
        public string As_MsgCd { get; private set; }
        public string As_MasterMsg { get; private set; }
        public string As_DetailMsg { get; private set; }
        public object Tag { get; private set; }

        public MsgException(object as_MsgType, object as_Type, object as_MsgCd, object as_MasterMsg, object as_DetailMsg, object tag = null)
        {
            As_MsgType = as_MsgType.ToString();
            As_Type = as_Type.ToString();
            As_MsgCd = as_MsgCd.ToString();
            As_MasterMsg = as_MasterMsg.ToString();
            As_DetailMsg = as_DetailMsg.ToString();
            Tag = tag;
        }
    }

    public static class ExSummary
    {
        /// <summary>
        /// Footer 합계 컬럼 셋팅
        /// </summary>
        public static void ExSetSummary(this GridView @this, bool tipFlag = true)
        {
            var numericCols = @this.Columns.Where(col =>
            {
                var type = col.ColumnType.Name;
                return type == "Integer" || type == "Decimal" || type == "Double";
            }).ToArray();
            if (!numericCols.Any()) return;

            var field = new string[numericCols.Length + 1];
            field[numericCols.Length] = @this.GridControl.Tag.ToString();
            for (var i = 0; i < numericCols.Length; i++)
                field[i] = numericCols[i].FieldName;

            new[] { field }.ExSetSummary(new List<GridControl> { @this.GridControl }, null, false, tipFlag);
        }

        /// <summary>
        /// Footer 합계 컬럼 개별 셋팅
        /// </summary>
        public static void ExSetSummary(this IEnumerable<string[]> @this, IList<GridControl> gridControls, Type type = null, bool chkFlag = false, bool tipFlag = true)
        {
            if (type == null) type = typeof(decimal);
            if (type != typeof(int) && type != typeof(decimal) && type != typeof(double)) return;

            @this.ForEach(fields =>
            {
                gridControls.Where(grid => fields != null && grid.Tag.Equals(fields.Last())).ForEach(grid =>
                {
                    var view = grid.MainView as GridView;
                    if (view == null) return;

                    var chkCol = "";
                    if (chkFlag && (chkCol = view.Columns.Select(col => col.FieldName).FirstOrDefault(name => name.IsMatch("CHK"))) == null) return;

                    view.OptionsView.ShowFooter = true;

                    for (var i = 0; i < fields.Length - 1; i++)
                    {
                        view.Columns[fields[i]].Summary.Add(SummaryItemType.Custom, fields[i], string.Format("{{0:{0}}}", ((RepositoryItemTextEdit)view.Columns[fields[i]].ColumnEdit).Mask.EditMask));

                        if (!tipFlag) continue;

                        var pos = view.VisibleColumns.IndexOf(view.Columns[fields[i]]) - 1;
                        var prePos = view.VisibleColumns.IndexOf(view.Columns[fields[i == 0 ? fields.Length - 1 : i - 1]]);
                        if (pos >= 0 && pos != prePos)
                            view.VisibleColumns[pos].Summary.Add(SummaryItemType.Custom, view.VisibleColumns[pos].FieldName, "합계");
                    }

                    MethodInfo info;
                    if ((info = type.GetMethod("Parse", new[] { typeof(string) })) == null) return;
                    dynamic parse;
                    dynamic values;
                    if (type == typeof(int))
                    {
                        parse = (Func<string, int>)info.CreateDelegate(typeof(Func<string, int>));
                        values = new int[fields.Length - 1];
                    }
                    else if (type == typeof(decimal))
                    {
                        parse = (Func<string, decimal>)info.CreateDelegate(typeof(Func<string, decimal>));
                        values = new decimal[fields.Length - 1];
                    }
                    else if (type == typeof(double))
                    {
                        parse = (Func<string, double>)info.CreateDelegate(typeof(Func<string, double>));
                        values = new double[fields.Length - 1];
                    }
                    else return;

                    view.CustomSummaryCalculate += (sender, e) =>
                    {
                        var item = e.Item as GridSummaryItem;
                        if (item == null) return;

                        var index = Array.FindIndex(fields, t => t.IsSame(item.FieldName));
                        if (index < 0) return;

                        if (!e.IsTotalSummary || item.FieldName != fields[index]) return;

                        switch (e.SummaryProcess)
                        {
                            case CustomSummaryProcess.Start:
                                values[index] = 0;
                                break;

                            case CustomSummaryProcess.Calculate:
                                if (chkFlag && view.GetDataRow(e.RowHandle)[chkCol].Equals(false)) return;

                                values[index] += parse(e.FieldValue.IsBlank(0).ToString());
                                break;

                            case CustomSummaryProcess.Finalize:
                                e.TotalValue = values[index];
                                break;
                        }
                    };
                    view.CellValueChanged += (sender, args) =>
                    {
                        if (chkFlag && args.Column.FieldName.Equals(chkCol) || fields.Contains(args.Column.FieldName))
                            view.UpdateSummary();
                    };
                    view.HiddenEditor += (o, args) => view.UpdateSummary();
                    view.Events()[view.GetEventKeyByName(EventName.CustomDrawFooterCell)].GetInvocationList()
                        .OfType<FooterCellCustomDrawEventHandler>()
                        .ForEach(@event => view.CustomDrawFooterCell -= @event);
                    view.CustomDrawFooterCell += (sender, args) =>
                    {
                        var brush = args.Cache.GetSolidBrush(chkFlag ? Color.Olive : Color.FromArgb(70, 130, 195));
                        args.Cache.FillRectangle(brush, args.Bounds);

                        args.Appearance.ForeColor = Color.White;
                        var rectangle = args.Bounds;
                        rectangle.Inflate(-2, 0);
                        args.Appearance.DrawString(args.Cache, args.Info.DisplayText, rectangle);

                        args.Handled = true;
                    };
                });
            });
        }
    }

    public static class ExObject
    {
        public static bool IsNull(this object @this)
        {
            return @this == null || @this == DBNull.Value;
        }

        public static object IsNull(this object @this, object target)
        {
            return @this.IsNull() ? target : @this;
        }

        public static bool IsBlank(this object @this)
        {
            return @this.IsNull() || @this.ToString().Trim().Equals(string.Empty);
        }

        public static object IsBlank(this object @this, object target)
        {
            return @this.IsBlank() ? target : @this;
        }

        public static bool IsSame(this object @this, object _, bool ignoreBlank = true, bool ignoreCase = false)
        {
            @this = ignoreBlank ? @this.IsBlank("") : @this;
            @this = ignoreCase && !@this.IsBlank() ? @this.ToString().ToUpper() : @this;
            _ = ignoreBlank ? _.IsBlank("") : _;
            _ = ignoreCase && !_.IsBlank() ? _.ToString().ToUpper() : _;
            return @this == null ? _ == null : @this.Equals(_);
        }

        public static bool IsMatch(this object @this, object _, RegexOptions opt = RegexOptions.IgnoreCase)
        {
            return Regex.IsMatch((@this ?? "").ToString(), "^" + (_ ?? "") + "$", opt);
        }

        public static object IsMatch(this object @this, object _, object target, RegexOptions opt = RegexOptions.None)
        {
            return @this.IsMatch(_, opt) ? target : @this;
        }

        /// <summary>
        /// object로 업캐스팅 되어진<br/>
        /// BindingSource, DataSet, DataTable, DataView로 부터 DataTable 받아오기<br/>
        /// (실패시 null 리턴)
        /// </summary>
        public static DataTable ToDataTable(this object src)
        {
            var bindingSrc = src as BindingSource;
            if (bindingSrc != null)
                src = bindingSrc.DataSource;

            if (src is DataSet)
                return ((DataSet)src).Tables[0];
            if (src is DataTable)
                return (DataTable)src;
            if (src is DataView)
                return ((DataView)src).ToTable();

            return null;
        }

        /// <summary>
        /// ToString() 메서드 호출 시, DateTime으로 변경가능한 포맷을 가진 object을(를)<br/>
        /// DateTime으로 변경하는 확장메서드<br/>
        /// (실패시 null 리턴, object로 업캐스팅 됐을 때 주로 사용)
        /// </summary>
        public static DateTime? ToDateTime(this object @this)
        {
            DateTime result;
            if (@this.IsBlank()) return null;
            return DateTime.TryParse(@this.ToString(), out result) ? (DateTime?)result : null;
        }

        /// <summary>
        /// ToString() 메서드 호출 시, 정수로 변경가능한 포맷을 가진 object을(를)<br/>
        /// int로 변경하는 확장메서드<br/>
        /// (실패시 failure 리턴(Default 0), object로 업캐스팅 됐을 때 주로 사용)
        /// </summary>
        public static int ToInt32(this object @this, int failure = 0)
        {
            int result;
            if (@this.IsBlank()) return failure;
            return int.TryParse(@this.ToString(), out result) ? result : failure;
        }

        /// <summary>
        /// ToString() 메서드 호출 시, Decimal로 변경가능한 포맷을 가진 object을(를)<br/>
        /// Decimal로 변경하는 확장메서드<br/>
        /// (실패시 failure 리턴(Default 0), object로 업캐스팅 됐을 때 주로 사용)
        /// </summary>
        public static decimal ToDecimal(this object @this, decimal failure = 0m)
        {
            decimal result;
            if (@this.IsBlank()) return failure;
            return decimal.TryParse(@this.ToString(), out result) ? result : failure;
        }

        /// <summary>
        /// ToString() 메서드 호출 시, Double로 변경가능한 포맷을 가진 object을(를)<br/>
        /// Double로 변경하는 확장메서드<br/>
        /// (실패시 failure 리턴(Default 0), object로 업캐스팅 됐을 때 주로 사용)
        /// </summary>
        public static double ToDouble(this object @this, double failure = 0d)
        {
            double result;
            if (@this.IsBlank()) return failure;
            return double.TryParse(@this.ToString(), out result) ? result : failure;
        }
    }

    public static class ExControl
    {
        public static List<int> GetGridTags(this Control @this)
        {
            return ComFunction.GetControls(@this).OfType<UC_XtraGrid>().Select(grid => Convert.ToInt32(grid.Tag)).ToList();
        }
    }

    public static class ExDataRow
    {
        /// <exception cref="Exception">when things go wrong.</exception>
        public static DataRow Clone(this DataRow @this)
        {
            if (!ExDataTable._ManagedTable.ContainsKey(@this.Table))
                throw new Exception("StopChangedEvent(this DataTable @this)를 먼저 호출해주세요. =ㅅ=乃");
            var row = @this.Table.NewRow();
            row.ItemArray = @this.ItemArray;
            return row;
        }
    }

    public static class ExDataTable
    {
        private static DataColumnChangeEventHandler[] GetEnrolledColumnChangedEvent(this DataTable @this)
        {
            var info = typeof(DataTable).GetField("onColumnChangedDelegate", BindingFlags.Instance | BindingFlags.NonPublic);
            if (info == null) return null;
            var @delegate = info.GetValue(@this) as Delegate;
            return @delegate == null ? null : @delegate.GetInvocationList().OfExactType<DataColumnChangeEventHandler>().ToArray();
        }

        private static DataRowChangeEventHandler[] GetEnrolledRowChangedEvent(this DataTable @this)
        {
            var info = typeof(DataTable).GetField("onRowChangedDelegate", BindingFlags.Instance | BindingFlags.NonPublic);
            if (info == null) return null;
            var @delegate = info.GetValue(@this) as Delegate;
            return @delegate == null ? null : @delegate.GetInvocationList().OfExactType<DataRowChangeEventHandler>().ToArray();
        }

        internal static readonly Dictionary<DataTable, dynamic> _ManagedTable = new Dictionary<DataTable, dynamic>();

        public static void StopChangedEvent(this DataTable @this)
        {
            if (_ManagedTable.ContainsKey(@this)) return;

            _ManagedTable.Add(@this, new
            {
                ColumnChanged = @this.GetEnrolledColumnChangedEvent(),
                RowChanged = @this.GetEnrolledRowChangedEvent()
            });

            if (_ManagedTable[@this].ColumnChanged != null)
                ((DataColumnChangeEventHandler[])_ManagedTable[@this].ColumnChanged).ForEach(@event => @this.ColumnChanged -= @event);
            if (_ManagedTable[@this].RowChanged != null)
                ((DataRowChangeEventHandler[])_ManagedTable[@this].RowChanged).ForEach(@event => @this.RowChanged -= @event);
        }

        public static void StartChangedEvent(this DataTable @this)
        {
            if (!_ManagedTable.ContainsKey(@this)) return;

            if (_ManagedTable[@this].ColumnChanged != null)
                ((DataColumnChangeEventHandler[])_ManagedTable[@this].ColumnChanged).ForEach(@event => @this.ColumnChanged += @event);
            if (_ManagedTable[@this].RowChanged != null)
                ((DataRowChangeEventHandler[])_ManagedTable[@this].RowChanged).ForEach(@event => @this.RowChanged += @event);

            _ManagedTable.Remove(@this);
        }
    }

    public static class ExBindingSource
    {
        public static void ReflectRowFilter(this BindingSource @this, GridView gridView)
        {
            var table = @this.ToDataTable();
            if (table == null) return;
            var dataView = table.DefaultView;

            dataView.ListChanged += (o, args) =>
            {
                if (dataView.RowFilter.IsBlank()) return;

                table = table.Clone();
                dataView.OfType<DataRowView>().ForEach(row => table.ImportRow(row.Row));
                @this.DataSource = table;
            };

            var list = gridView.Events()[gridView.GetEventKeyByName(EventName.CellValueChanged)].GetInvocationList().OfType<CellValueChangedEventHandler>().ToList();
            if (list.Contains(OnCellValueChanged)) return;
            list.ForEach(@event => gridView.CellValueChanged -= @event);
            gridView.CellValueChanged += OnCellValueChanged;
            list.ForEach(@event => gridView.CellValueChanged += @event);
        }

        private static void OnCellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            var view = (GridView)sender;
            var src = view.DataSource as BindingSource;
            if (src == null) return;
            src.EndEdit();
        }
    }

    public static class ExGridView
    {
        private static readonly CancelEventHandler Cancel = (sender, e) => e.Cancel = true;

        public static void ShowingEditorCancel(this GridView @this)
        {
            var handler = @this.Events()[@this.GetEventKeyByName(EventName.ShowingEditor)];
            if (handler == null || !handler.GetInvocationList().OfType<CancelEventHandler>().Contains(Cancel))
                @this.ShowingEditor += Cancel;
        }

        public static void ShowingEditorEnable(this GridView @this)
        {
            @this.ShowingEditor -= Cancel;
        }

        public static void ClearFilter(this GridView @this)
        {
            @this.ClearSorting();
            @this.ClearColumnsFilter();
            @this.ClearFindFilter();
        }

        public static List<string> GetColumnFields(this GridView @this)
        {
            return ((IList<MenuColumnInfo>)@this.Tag).Select(info => info.COL_ID).ToList();
        }

        public static object GetEventKeyByName(this GridView @this, EventName name)
        {
            FieldInfo info = null;

            switch (name)
            {
                case EventName.FocusedRowChanged:
                    info = typeof(ColumnView).GetField("focusedRowChanged", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.KeyDown:
                    info = typeof(BaseView).GetField("keyDown", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.KeyUp:
                    info = typeof(BaseView).GetField("keyUp", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.ClipboardRowPasting:
                    info = typeof(GridView).GetField("clipboardRowPasting", BindingFlags.Instance | BindingFlags.NonPublic);
                    break;
                case EventName.CustomDrawFooterCell:
                    info = typeof(GridView).GetField("customDrawFooterCell", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.CellValueChanged:
                    info = typeof(ColumnView).GetField("cellValueChanged", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.RowStyle:
                    info = typeof(GridView).GetField("rowStyle", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.ShowingEditor:
                    info = typeof(ColumnView).GetField("showingEditor", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
                case EventName.RowCellStyle:
                    info = typeof(GridView).GetField("rowCellStyle", BindingFlags.Static | BindingFlags.NonPublic);
                    break;
            }

            return info == null ? null : info.GetValue(@this);
        }

        public static void TriggerEvent(this GridView @this, EventName name, EventArgs args = null)
        {
            var handler = @this.Events()[@this.GetEventKeyByName(name)];
            if (handler == null) return;

            switch (name)
            {
                case EventName.FocusedRowChanged:
                    args = (EventArgs)args.IsNull(new FocusedRowChangedEventArgs(-1, @this.FocusedRowHandle));
                    if (!(args is FocusedRowChangedEventArgs)) return;
                    handler.GetInvocationList().OfType<FocusedRowChangedEventHandler>().ForEach(@event => @event(@this, (FocusedRowChangedEventArgs)args));
                    break;
                case EventName.KeyDown:
                    args = (EventArgs)args.IsNull(new KeyEventArgs(Keys.Enter));
                    if (!(args is KeyEventArgs)) return;
                    handler.GetInvocationList().OfType<KeyEventHandler>().ForEach(@event => @event(@this, (KeyEventArgs)args));
                    break;
                case EventName.KeyUp:
                    args = (EventArgs)args.IsNull(new KeyEventArgs(Keys.Enter));
                    if (!(args is KeyEventArgs)) return;
                    handler.GetInvocationList().OfType<KeyEventHandler>().ForEach(@event => @event(@this, (KeyEventArgs)args));
                    break;
                case EventName.ClipboardRowPasting:
                    if (!(args is ClipboardRowPastingEventArgs)) return;
                    handler.GetInvocationList().OfType<ClipboardRowPastingEventHandler>().ForEach(@event => @event(@this, (ClipboardRowPastingEventArgs)args));
                    break;
                case EventName.CustomDrawFooterCell:
                    if (!(args is FooterCellCustomDrawEventArgs)) return;
                    handler.GetInvocationList().OfType<FooterCellCustomDrawEventHandler>().ForEach(@event => @event(@this, (FooterCellCustomDrawEventArgs)args));
                    break;
                case EventName.CellValueChanged:
                    if (!(args is CellValueChangedEventArgs)) return;
                    handler.GetInvocationList().OfType<CellValueChangedEventHandler>().ForEach(@event => @event(@this, (CellValueChangedEventArgs)args));
                    break;
                case EventName.RowStyle:
                    if (!(args is RowStyleEventArgs)) return;
                    handler.GetInvocationList().OfType<RowStyleEventHandler>().ForEach(@event => @event(@this, (RowStyleEventArgs)args));
                    break;
                case EventName.ShowingEditor:
                    if (!(args is CancelEventArgs)) return;
                    handler.GetInvocationList().OfType<CancelEventHandler>().ForEach(@event => @event(@this, (CancelEventArgs)args));
                    break;
                case EventName.RowCellStyle:
                    if (!(args is RowCellStyleEventArgs)) return;
                    handler.GetInvocationList().OfType<RowCellStyleEventHandler>().ForEach(@event => @event(@this, (RowCellStyleEventArgs)args));
                    break;
            }
        }

        public static bool HasEnrolledEvent(this GridView @this, EventName name)
        {
            return @this.Events()[@this.GetEventKeyByName(name)] != null;
        }

        public static int GetGridTag(this GridView @this)
        {
            return Convert.ToInt32(@this.GridControl.Tag);
        }

        /// <summary>
        ///   <para>Returns the handle of the row which represents the specified record in the data source.</para>
        /// </summary>
        /// <param name="this">GridView with the same data source.</param>
        /// <param name="row">The record in the data source.</param>
        /// <returns>An integer value which represents the handle of the row which corresponds to the specified record in the data source.</returns>
        public static int GetRowHandle(this GridView @this, DataRow row)
        {
            if (row == null) return int.MinValue;
            if (@this == null) return int.MinValue;
            var table = @this.DataSource.ToDataTable();
            if (table == null) return int.MinValue;
            if (table != row.Table) return int.MinValue;

            int handle;
            for (handle = 0; handle < @this.RowCount; handle++)
            {
                if (!@this.IsDataRow(handle)) continue;
                if (@this.GetDataRow(handle).Equals(row)) break;
            }
            return handle == @this.RowCount ? int.MinValue : handle;
        }

        public static bool TryFocusChasedRow(this GridView @this, Func<DataRow, bool> chaseRow, bool isForcedFocus = false)
        {
            var table = @this.DataSource.ToDataTable();
            if (table == null) return false;
            var chasedRow = table.Rows.OfType<DataRow>().FirstOrDefault(chaseRow);
            if (chasedRow == null) return false;
            var handle = @this.GetRowHandle(chasedRow);
            if (!@this.IsDataRow(handle))
            {
                @this.ClearFilter();
                handle = @this.GetRowHandle(chasedRow);
                if (!@this.IsDataRow(handle)) return false;
            }

            @this.ClearSelection();
            @this.FocusedRowHandle = handle;
            if (@this.FocusedRowHandle == handle) return true;

            if (!isForcedFocus) return false;
            var @lock = typeof(ColumnView).GetField("lockFocusedRowChange", BindingFlags.Instance | BindingFlags.NonPublic);
            if (@lock == null) return false;
            var tmp = @lock.GetValue(@this);
            @lock.SetValue(@this, 0);
            @this.FocusedRowHandle = handle;
            @lock.SetValue(@this, tmp);

            FocusedRowChangedEventHandler @event = null;
            @event = (o, args) =>
            {
                @this.FocusedRowChanged -= @event;
                if (@this.FocusedRowHandle == handle) return;
                @this.FocusedRowHandle = handle;
            };
            @this.FocusedRowChanged += @event;

            return true;
        }

        /// <summary>
        /// 행 추가 (position == null이면, 포커스된 행의 뒷쪽에 추가)
        /// </summary>
        public static DataRow ExAppendRow(this GridView @this, int? pos = null)
        {
            var table = @this.GridControl.DataSource.ToDataTable();
            if (table == null) return null;

            @this.ClearSelection();
            @this.ClearFilter();

            var row = table.NewRow();
            pos = (int?)pos.IsNull(@this.FocusedRowHandle);
            pos = @this.IsDataRow(pos.Value) ? (int?)@this.GetDataSourceRowIndex(pos.Value) : null;
            if (pos == null) table.Rows.Add(row);
            else table.Rows.InsertAt(row, pos.Value + 1);

            @this.FocusedRowHandle = @this.GetRowHandle(row);
            if (@this.VisibleColumns.Count > 0)
                @this.FocusedColumn = @this.VisibleColumns[0];

            return row;
        }

        /// <summary>
        /// 행 삭제
        /// </summary>
        public static void ExDeleteRow(this GridView @this)
        {
            var src = @this.DataSource as BindingSource;
            if (src == null) return;
            var table = src.ToDataTable();
            if (table == null) return;

            src.EndEdit();
            var handle = @this.FocusedRowHandle;
            var cnt = @this.DataRowCount;
            if (@this.IsFocusedRowChangeLocked()) @this.UnlockFocusedRowChange();
            @this.DeleteRow();
            if (handle != @this.FocusedRowHandle || cnt == @this.DataRowCount) return;
            @this.TriggerEvent(EventName.FocusedRowChanged);
        }

        /// <summary>
        /// 행 취소
        /// </summary>
        public static void ExCancelRow(this GridView @this)
        {
            var src = @this.DataSource as BindingSource;
            if (src == null) return;
            var table = src.ToDataTable();
            if (table == null) return;

            src.EndEdit();
            var handle = @this.FocusedRowHandle;
            var cnt = @this.DataRowCount;
            if (@this.IsFocusedRowChangeLocked()) @this.UnlockFocusedRowChange();
            @this.Cancel();
            if (handle != @this.FocusedRowHandle || cnt == @this.DataRowCount) return;
            @this.TriggerEvent(EventName.FocusedRowChanged);
        }

        public static bool ExHasChanges(this GridView @this)
        {
            if (@this == null) return false;
            var table = @this.GridControl.DataSource.ToDataTable();
            if (table == null) return false;
            return table.Columns.Contains("GU") && table.Rows.OfType<DataRow>().Any(row => row["GU"].IsMatch("[CUD]"));
        }

        public static bool ExRequiredCheck(this GridView @this, Func<DataRow, bool> where = null, bool showMessage = true, bool moveFocus = true)
        {
            if (@this == null) return false;
            var table = @this.GridControl.DataSource.ToDataTable();
            if (table == null) return false;
            if (where == null) where = row => true;
            return !table.Rows.OfType<DataRow>().Where(where).Any(row => @this.Columns.Any(col =>
            {
                if (!(col.Tag ?? "").ToString().Contains("R")) return false;
                if (!row[col.FieldName].IsBlank()) return false;
                if (showMessage)
                    ComFunction.ClsFnMsg("M", "A", "", "이 항목은 필수입력 항목입니다.", col.Caption);
                if (!moveFocus) return true;

                @this.Focus();
                @this.ClearFilter();
                @this.ClearSelection();
                @this.FocusedRowHandle = @this.GetRowHandle(row);
                @this.FocusedColumn = col;
                @this.SelectCell(@this.FocusedRowHandle, col);
                return true;
            }));
        }
    }

    public static class ExGridViewForLock
    {
        public static void LockFocusedRowChange(this GridView @this)
        {
            if (_handle.ContainsKey(@this)) return;
            _handle.Add(@this, @this.FocusedRowHandle);
            @this.MouseDown += OnMouseDown;
            @this.GridControl.ProcessGridKey += OnProcessGridKey;

            @this.GridControl.Paint += OnPaint;
            @this.Invalidate();
        }

        public static void UnlockFocusedRowChange(this GridView @this)
        {
            if (!_handle.ContainsKey(@this)) return;
            _handle.Remove(@this);
            @this.MouseDown -= OnMouseDown;
            @this.GridControl.ProcessGridKey -= OnProcessGridKey;

            @this.GridControl.Paint -= OnPaint;
            @this.Invalidate();
        }

        private static void OnPaint(object sender, PaintEventArgs e)
        {
            var view = (GridView)((GridControl)sender).MainView;
            var viewInfo = view.GetViewInfo() as GridViewInfo;
            if (viewInfo == null) return;
            var rowInfo = viewInfo.GetGridRowInfo(view.FocusedRowHandle);
            if (rowInfo == null) return;
            var bounds = rowInfo.Bounds;
            bounds.Inflate(0, -1);
            using (var pen = new Pen(Brushes.Crimson, 2))
                e.Graphics.DrawRectangle(pen, bounds);
        }

        private static readonly Dictionary<GridView, int> _handle = new Dictionary<GridView, int>();

        public static bool IsFocusedRowChangeLocked(this GridView @this)
        {
            var @lock = typeof(ColumnView).GetField("lockFocusedRowChange", BindingFlags.Instance | BindingFlags.NonPublic);
            if (@lock == null) return false;
            return _handle.ContainsKey(@this) || @lock.GetValue(@this).ToInt32() > 0;
        }

        private static void OnMouseDown(object sender, MouseEventArgs e)
        {
            var view = (GridView)sender;
            var info = view.CalcHitInfo(e.Location);
            DXMouseEventArgs.GetMouseArgs(e).Handled = view.FocusedRowHandle != info.RowHandle;
        }

        private static void OnProcessGridKey(object sender, KeyEventArgs e)
        {
            var view = (GridView)((GridControl)sender).MainView;

            switch (e.KeyCode)
            {
                case Keys.Up:
                case Keys.Down:
                    e.Handled = true;
                    break;
                case Keys.Left:
                    if (view.VisibleColumns.IndexOf(view.FocusedColumn) == 0)
                        e.Handled = true;
                    break;
                case Keys.Right:
                    if (view.VisibleColumns.Last().Equals(view.FocusedColumn))
                        e.Handled = true;
                    break;
            }
        }
    }

    public static class ExGridViewForIntegration
    {
        /// <exception cref="Exception">when things go wrong.</exception>
        public static IList<string> ExGetExceptColumns(this GridView @this)
        {
            var info = @this.GetType().GetProperty("ExceptColumns");
            if (info == null)
                throw new Exception("UC_GridView, UC_BandedGridView, UC_AdvBandedGridView(이)가 맞는지 다시 확인해주세요.");
            return (IList<string>)info.GetValue(@this);
        }

        /// <exception cref="Exception">when things go wrong.</exception>
        public static bool ExGetIsAutoGuFlag(this GridView @this)
        {
            var info = @this.GetType().GetProperty("IsAutoGuFlag");
            if (info == null)
                throw new Exception("UC_GridView, UC_BandedGridView, UC_AdvBandedGridView(이)가 맞는지 다시 확인해주세요.");
            return (bool)info.GetValue(@this);
        }

        /// <exception cref="Exception">when things go wrong.</exception>
        public static bool ExGetIsActiveGrid(this GridView @this)
        {
            var info = @this.GetType().GetProperty("IsActiveGrid");
            if (info == null)
                throw new Exception("UC_GridView, UC_BandedGridView, UC_AdvBandedGridView(이)가 맞는지 다시 확인해주세요.");
            return (bool)info.GetValue(@this);
        }

        /// <exception cref="Exception">when things go wrong.</exception>
        public static void ExSetIsAutoGuFlag(this GridView @this, bool isAutoGuFlag)
        {
            var info = @this.GetType().GetProperty("IsAutoGuFlag");
            if (info == null)
                throw new Exception("UC_GridView, UC_BandedGridView, UC_AdvBandedGridView(이)가 맞는지 다시 확인해주세요.");
            info.SetValue(@this, isAutoGuFlag);
        }

        /// <exception cref="Exception">when things go wrong.</exception>
        public static void ExSetIsActiveGrid(this GridView @this, bool isActiveGrid)
        {
            var info = @this.GetType().GetProperty("IsActiveGrid");
            if (info == null)
                throw new Exception("UC_GridView, UC_BandedGridView, UC_AdvBandedGridView(이)가 맞는지 다시 확인해주세요.");
            info.SetValue(@this, isActiveGrid);
        }
    }

    public static class NativeMethods
    {
        [DllImport("user32.dll")]
        private static extern short GetKeyState(int key);

        private const int KEY_PRESSED = 0x8000;
        private const int VK_UP = 0x26;
        private const int VK_DOWN = 0x28;

        public static bool IsUpKeyPressed()
        {
            return (GetKeyState(VK_UP) & KEY_PRESSED) != 0;
        }

        public static bool IsDownKeyPressed()
        {
            return (GetKeyState(VK_DOWN) & KEY_PRESSED) != 0;
        }
    }

    public enum EventName
    {
        FocusedRowChanged,
        KeyDown,
        KeyUp,
        ClipboardRowPasting,
        CustomDrawFooterCell,
        CellValueChanged,
        RowStyle,
        ShowingEditor,
        RowCellStyle
    }

    public enum Temp
    {
        _0,
        _1,
        _2,
        _3,
        _4,
        _5,
        _6,
        _7,
        _8,
        _9,
    }

    #endregion

}