﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using ClsComm;
using Common.Controls.Common;
using DevExpress.LookAndFeel;
using DevExpress.Utils.Extensions;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;

namespace Common
{
    public partial class ViewPopupDev2 : ViewPopupDev
    {
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, UC_XtraGrid> _Grid { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid의 MainView를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, GridView> _View { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 BindingSource를 바로 얻을 수 있습니다.
        /// </summary>
        protected Dictionary<object, BindingSource> _Src { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 BindingSource의 DataTable을 바로 얻을 수 있습니다.
        /// </summary>
        public Dictionary<object, DataTable> _Table { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid와 바인딩된 모든 DataRow의 리스트를 바로 얻을 수 있습니다.
        /// </summary>
        public Rows _Rows { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid에 포커스 되어진 DataRow를 바로 얻을 수 있습니다.
        /// </summary>
        protected FocusedRow _FocusedRow { get; private set; }
        /// <summary>
        /// GridControl의 Tag 숫자와 일치하는 인덱스를 사용하시면,<br/> 
        /// 해당 Grid의 ColumnEdit들을 Column의 FiledName으로 접근할 수 있는 Dictionary가 제공됩니다.
        /// </summary>
        protected ColumnEdits _ColumnEdits { get; private set; }
        /// <summary>
        /// GridControl의 모든 Tag를 Popup Enum으로 담고 있습니다.
        /// </summary>
        protected List<Popup> _Tag { get; private set; }
        /// <summary>
        /// ActiveGrid의 Tag를 int 타입으로 얻습니다.
        /// </summary>
        protected Popup _ActiveGrid { get; private set; }
        /// <summary>
        /// _Table[tag]의 Reference가 변경되었습니다.
        /// </summary>
        protected event TableChangedEventHandler TableChanged;
        protected delegate void TableChangedEventHandler(object sender, TableChangedEventArgs e);
        protected class TableChangedEventArgs : EventArgs
        {
            public int Tag { get; private set; }
            public TableChangedEventArgs(int tag) { Tag = tag; }
        }
        /// <summary>
        /// _Table[tag]의 Reference가 변경되기 전입니다.
        /// </summary>
        protected event TableChangingEventHandler TableChanging;
        protected delegate void TableChangingEventHandler(object sender, TableChangingEventArgs e);
        protected class TableChangingEventArgs : EventArgs
        {
            public int Tag { get; private set; }
            public TableChangingEventArgs(int tag) { Tag = tag; }
        }

        public ViewPopupDev2()
        {
            InitializeComponent();

            var info = typeof(Form).GetField("EVENT_LOAD", BindingFlags.Static | BindingFlags.NonPublic);
            if (info == null) return;
            var list = Events[info.GetValue(null)].GetInvocationList().OfType<EventHandler>().ToList();
            list.ForEach(@event => Load -= @event);
            Load += (sender, args) => Menu_ID = clsFunction.GetMenuId(Name[0].ToString(), Name);
            list.ForEach(@event => Load += @event);
        }

        private void ViewPopupDev2_Load(object sender, EventArgs e)
        {
            if (DesignMode) return;
            if (SelectView.Columns.ColumnByFieldName("Chk") == null)
                throw new Exception("Chk 열을 꼭 포함시켜주세요.(필요없다면 메뉴컬럼등록에서 숨김 설정하세요)");

            if (ActiveGrid == null) return;
            _ActiveGrid = (Popup)ActiveGrid.Tag.ToInt32();

            _Grid = new Dictionary<object, UC_XtraGrid>
            {
                {Popup.Select, SelectGrid},
                {Popup.Result, ResultGrid}
            };
            _View = new Dictionary<object, GridView>();
            _Src = new Dictionary<object, BindingSource>();
            _Table = new Dictionary<object, DataTable>();
            _Rows = new Rows { _Table = _Table };
            _FocusedRow = new FocusedRow { _View = _View };
            _ColumnEdits = new ColumnEdits { _View = _View };
            _Tag = new List<Popup>();

            _Grid.ForEach(pair =>
            {
                _Tag.Add((Popup)pair.Key);

                pair.Value.Enter += (o, args) => _ActiveGrid = (Popup)pair.Key;
                _View.Add(pair.Key, (GridView)pair.Value.MainView);
                _View[pair.Key].ExGetExceptColumns().Add("GU");
                _View[pair.Key].ExSetIsAutoGuFlag(false);

                _Table.Add(pair.Key, null);
                _Src.Add(pair.Key, new BindingSource());
                _Src[pair.Key].CurrentChanged += OnCurrentChanged;
                _Src[pair.Key].DataSourceChanged += (o, args) => OnCurrentChanged(_Src[pair.Key], args);
                _Src[pair.Key].BindingComplete += OnBindingComplete;
            });

            Shown += (o, args) =>
            {
                _Tag.ForEach(tag =>
                {
                    // grid.DataSource는 ClsFunction.SetGridColumn()에서 오류가 없었다면 생성되야합니다.
                    // null인 경우, 메뉴컬럼등록을 다시 확인해 주세요. 충분히 해결하실 수 있을겁니다 =ㅅ=乃
                    //
                    // 또는 !! Load 이벤트 시점에서 조회하시면, 사용할 수 없습니다. 지금 등록된 Shown 보다 뒤에서 조회해주세요.
                    if (_Grid[tag].DataSource == null)
                        throw new Exception("메뉴컬럼등록을 다시 확인해 주세요.");
                    _Src[tag].DataSource = _Grid[tag].DataSource;
                    _Grid[tag].DataSource = _Src[tag];
                });
            };

            Shown += (o, args) =>
            {
                _Search();
                var edit = ComFunction.GetControls(this).FirstOrDefault(ctrl => ctrl.Name.Equals("s_Search")) as TextEdit;
                if (edit == null) return;

                edit.GotFocus += (o1, args1) => edit.SelectAll();
                edit.Click += (o1, args1) => edit.SelectAll();
                edit.KeyDown += (o1, args1) =>
                {
                    if (args1.KeyData != Keys.Enter) return;
                    _Search();
                };
            };

            _View.Values.ForEach(view =>
            {
                if (view is UC_GridView)
                    ((UC_GridView)view).EnableAppearanceEvenRow = true;
                else if (view is UC_BandedGridView)
                    ((UC_BandedGridView)view).EnableAppearanceEvenRow = true;
                else if (view is UC_AdvBandedGridView)
                    ((UC_AdvBandedGridView)view).EnableAppearanceEvenRow = true;
            });

            RowCellStyleEventHandler @event = (o, args) =>
            {
                if (((GridView)o).GetDataRow(args.RowHandle)["Chk"].Equals(false)) return;
                args.Appearance.BackColor = o.Equals(_View[Popup.Select]) ? Color.LightGreen : Color.LightPink;
            };
            _View[Popup.Select].RowCellStyle += @event;
            _View[Popup.Result].RowCellStyle += @event;

            DataColumnChangeEventHandler btnEnableEvent = (o1, args1) =>
            {
                var tag = _Table.First(pair => pair.Value.Equals(o1)).Key;
                var btn = tag.Equals(Popup.Select) ? btn_ChkRowMoveDown : btn_ChkRowMoveUp;
                var color = tag.Equals(Popup.Select) ? DXSkinColors.FillColors.Success : DXSkinColors.FillColors.Danger;
                var hasChk = _Rows[tag].Exists(row => row["Chk"].Equals(true));

                btn.Enabled = hasChk;
                btn.Appearance.BackColor = hasChk ? color : Color.Black;
            };
            TableChanged += (o1, args1) =>
            {
                _Table[Popup.Select].ColumnChanged += btnEnableEvent;
                btnEnableEvent(_Table[Popup.Select], null);
            };
            Shown += (o, args) =>
            {
                _Table[Popup.Select].ColumnChanged += btnEnableEvent;
                _Table[Popup.Result].ColumnChanged += btnEnableEvent;
                btnEnableEvent(_Table[Popup.Select], null);
                btnEnableEvent(_Table[Popup.Result], null);
            };

            btn_Search.Click += (o, args) => _Search();
            btn_Cancel.Click += (o, args) => DialogResult = DialogResult.Cancel;
            btn_OK.Click += (o, args) =>
            {
                if (!_MultiFlag && _Table[Popup.Result].Rows.Count == 0)
                    _View[Popup.Select].TriggerEvent(EventName.KeyDown);
                _Finish();
            };
        }

        private void OnCurrentChanged(object sender, EventArgs e)
        {
            var src = (BindingSource)sender;
            var tag = _Src.First(pair => pair.Value == src).Key;

            var table = _Src[tag].DataSource.ToDataTable();
            if (_Table[tag] == table) return;

            // _Src[tag].DataSource = dt; << 지금 이 순간을 포착했습니다
            if (_View[tag].IsFocusedRowChangeLocked()) _View[tag].UnlockFocusedRowChange();

            if (_Table[tag] != null && TableChanging != null)
                TableChanging(this, new TableChangingEventArgs((int)tag));

            if (_Table[tag] != null)
                _Table[tag].Dispose();
            _Table[tag] = table;

            if (_Table[tag].Columns.Contains("GU"))
                _Table[tag].Columns["GU"].DefaultValue = "C";
            _Table[tag].Columns
                .OfType<DataColumn>()
                .Where(col => col.DataType == typeof(bool) && col.DefaultValue == DBNull.Value)
                .ForEach(col => col.DefaultValue = false);
            _Table[tag].ColumnChanged += (o, args) =>
            {
                if (!_Table[tag].Columns.Contains("GU")) return;
                if (args.Row["GU"].IsMatch("[CUD]")) return;
                if (_View[tag].ExGetExceptColumns().Contains(args.Column.ColumnName)) return;

                args.Row["GU"] = "U";
            };

            if (TableChanged != null)
                TableChanged(this, new TableChangedEventArgs((int)tag));

            // DataSource 등록 후 행변경 강제 발생을 위한 밑 작업입니다.
            // tag번째 그리드는 이 순간 Invalid Row를 포커스 후(rowHandle = -2147483648), 이벤트 FocusedRowChanged()가 호출되어집니다.
            // 이 후, 다음 루틴으로 이벤트 FocusedRowChanged()가 불리는 것을 잠시 막습니다.
            _Grid[tag].DataSource = null;

            // 바인딩소스의 객체를 사용하기 위한 준비과정 입니다.
            src.CurrentChanged -= OnCurrentChanged;
            _Src[tag].ResetBindings(true);
            src.CurrentChanged += OnCurrentChanged;

            _View[tag].ClearFilter();

            // 마무리 =ㅅ=乃
            _Grid[tag].DataSource = _Src[tag]; // 이벤트 FocusedRowChanged()가 다시 불립니다.

            if (!_MultiFlag) return;
            if (_Table[Popup.Result] == null) return;
            if (_Table[Popup.Result].Rows.Count == 0) return;

            var columnFields = _View[Popup.Select].GetColumnFields();
            columnFields.Remove("GU");

            _Rows[Popup.Result].ForEach(resultRow =>
            {
                var sameRow = _Rows[Popup.Select].FirstOrDefault(selectRow => columnFields.All(col => selectRow[col].Equals(resultRow[col])));
                if (sameRow != null) sameRow.Delete();
            });
        }

        /// <summary>
        /// For using BindingSource. This method will be make to apply immediately. ( Eg. ("TEST")Txt_Test.Text -> ultraGrid1.ActiveRow.Cells["TEST"].Value )
        /// 바인딩소스를 사용하기위함. 해당 기능은 적용이 즉시 되도록함.( Eg. ("TEST")Txt_Test.Text -> ultraGrid1.ActiveRow.Cells["TEST"].Value )
        /// </summary>
        private static void OnBindingComplete(object sender, BindingCompleteEventArgs e)
        {
            // Check if the data source has been updated, and that no error has occurred.
            if (e.BindingCompleteContext == BindingCompleteContext.DataSourceUpdate && e.Exception == null)
                e.Binding.BindingManagerBase.EndCurrentEdit(); // If not, end the current edit.

            e.Binding.ControlUpdateMode = ControlUpdateMode.OnPropertyChanged;
            ((BindingSource)sender).EndEdit();
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool _MultiFlag
        {
            get
            {
                return SelectView.Columns["Chk"].Visible;
            }
            set
            {
                if (value) return;

                tlp.RowStyles[(int)Popup.Select].Height = 0;
                tlp.RowStyles[(int)Popup.Result].Height = 0;
                ResultGrid.Enabled = false;
                btn_ChkRowMoveDown.Enabled = false;
                btn_ChkRowMoveUp.Enabled = false;

                EventHandler @event = null;
                @event = (sender, args) =>
                {
                    SelectView.Columns["Chk"].Visible = false;
                    SelectView.DataSourceChanged -= @event;
                };
                SelectView.DataSourceChanged += @event;
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData != Keys.Enter) return;

            var tag = (Popup)((GridView)sender).GetGridTag();
            if (_FocusedRow[tag] == null) return;
            _FocusedRow[tag]["Chk"] = "TRUE";
            OnButtonClick_ChkRowMove(sender, e);

            if (_MultiFlag) return;
            _Finish();
        }

        private void OnDoubleClick(object sender, EventArgs e)
        {
            var view = (GridView)sender;
            var point = view.GridControl.PointToClient(MousePosition);
            var hitInfo = view.CalcHitInfo(point);
            if (!hitInfo.InRowCell) return;

            view.TriggerEvent(EventName.KeyDown);
        }

        private void OnButtonClick_ChkRowMove(object sender, EventArgs e)
        {
            var isDown = sender == btn_ChkRowMoveDown || sender == _View[Popup.Select];
            var from = isDown ? Popup.Select : Popup.Result;
            var to = isDown ? Popup.Result : Popup.Select;

            foreach (var row in _Rows[from].Where(row => row["Chk"].Equals(true)))
            {
                row["Chk"] = false;
                _View[to].ExAppendRow();
                _View[to].GetColumnFields().ForEach(col => _FocusedRow[to][col] = row[col]);
                row.Delete();
            }
        }

        protected void _Finish()
        {
            _Table[Popup.Result].AcceptChanges();
            DialogResult = _Table[Popup.Result].Rows.Count == 0 ? DialogResult.Abort : DialogResult.OK;
            if (DialogResult == DialogResult.OK) return;
            ComFunction.ClsFnMsg("A", "A", "Y547", "", ""); // 선택된 품목이 없습니다.
        }
    }

    public enum Popup
    {
        Select = 1,
        Result = 2
    }
}